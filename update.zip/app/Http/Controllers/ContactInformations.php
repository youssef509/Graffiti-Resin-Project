<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContactInformations extends Controller
{
    //
}
