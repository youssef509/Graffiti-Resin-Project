
<img src="frontend/assets/img/gd-logo.png" alt="Logo">