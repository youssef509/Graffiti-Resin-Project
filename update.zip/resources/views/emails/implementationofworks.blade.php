<html>
<body>
<h2>طلب عرض سعر تنفيذ أعمال جديد!'</h2>
<p><strong>Name:</strong> {{ $data['name'] }}</p>
<p><strong>Age:</strong> {{ $data['client_category'] }}</p>
<p><strong>Phone:</strong> {{ $data['phone'] }}</p>
<p><strong>City:</strong> {{ $data['city'] }}</p>
</body>
</html>
