<html>
<body>
<h2>طلب  موزع معتمد جديد!'</h2>
<p><strong>Name:</strong> {{ $data['name'] }}</p>
<p><strong>Phone:</strong> {{ $data['phone'] }}</p>
<p><strong>City:</strong> {{ $data['city'] }}</p>
<p><strong>Street:</strong> {{ $data['street'] }}</p>
</body>
</html>
