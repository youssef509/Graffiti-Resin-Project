<?php

return [
    "Home" => "Home",
    "Projects" => "Projects",
    "Services" => "Services",
    "Blog" => "Blog",
    "Contact" => "Contact",
    "About" => "About Us",
    "Languages" => "Languages",
    "QuickLinks" => "Quick Links",
    "RecentNews" => "Recent News",
    "Contacts" => "Contacts",
    "RequestQuote" => "Request Quote",
    "PrivacyPolicy" => "Privacy Policy",
    "FAQ" => "FAQ",
    "OOPS" => "OOPS!",
    "error404" => "error 404! page Not Found",
    "Backtohomepage" => "Back to homepage",
    "HomeAboutUs" => "About Graffiti Resin Company",
];
