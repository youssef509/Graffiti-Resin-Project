<?php

return [
    "Home" => "الرئيسية",
    "Projects" => "المشاريع",
    "Services" => "الخدمات",
    "Blog" => "المقالات",
    "Contact" => "تواصل معنا",
    "About" => "من نحن",
    "Languages" => "اللغات",
    "QuickLinks" => "روابط سريعة",
    "RecentNews" => "المضاف حديثا",
    "Contacts" => "التواصل",
    "RequestQuote" => "طلب استشارة",
    "PrivacyPolicy" => "سياسة الخصوصية",
    "FAQ" => "الأسئلة الشائعة",
    "OOPS" => "اوبس!!",
    "error404" => "خطأ404!الصفحة غير موجودة",
    "Backtohomepage" => "العودة للصفحة الرئيسية",
    "HomeAboutUs" => "عن شركة جرافيتي ريزن",
];
