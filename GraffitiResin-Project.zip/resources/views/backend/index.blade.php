@extends('backend.partials.layout')

@section('title')
   لوحة التحكم
@endsection



@section('page-content')

@endsection
