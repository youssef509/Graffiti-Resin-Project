<?php

namespace App\Http\Controllers\Admin\Quote;

use App\Http\Controllers\Controller;

class ImplementationofWorksController extends Controller
{
    //
}
