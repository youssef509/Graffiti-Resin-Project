<?php

namespace App\Http\Controllers\Admin\Quote;

use App\Http\Controllers\Controller;

class PurchasingMaterialsController extends Controller
{
    //
}
