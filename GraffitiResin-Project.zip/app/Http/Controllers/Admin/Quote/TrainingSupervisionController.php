<?php

namespace App\Http\Controllers\Admin\Quote;
use App\Models\TrainingSupervision;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;
use App\Mail\TrainingSupervision as TrainingSupervisionMail;
class TrainingSupervisionController extends Controller
{
    public function store() {
        request()->validate([
            'name' => ['required'],
            'age' => ['required'],
            'phone' => ['required'],
            'city' => ['required'],
            'specialization' => ['required'],
            'current_job' => ['required'],
            'reason' => ['required'],
        ]);

        $data = TrainingSupervision::create([
            'name' => request()->name,
            'age' => request()->age,
            'phone' => request()->phone,
            'city' => request()->city,
            'specialization' => request()->specialization,
            'current_job' => request()->current_job,
            'reason' => request()->reason,
        ]);
        // Send the email to the admin
        // Send the email to the admin with the data as an array
        Mail::to('youssef201.dev@gmail.com')->send(new TrainingSupervisionMail($data->toArray()));
        return to_route('quote.index')->with('success-create', 'تم اضافة العنصر بنجاح');
    }
}
