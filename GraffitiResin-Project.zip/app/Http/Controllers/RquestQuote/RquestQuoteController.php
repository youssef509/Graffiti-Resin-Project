<?php

namespace App\Http\Controllers\RquestQuote;

use App\Http\Controllers\Controller;

class RquestQuoteController extends Controller
{
    public function index() {
        return view('frontend.RquestQuote.index');
    }
}
