<?php

namespace App\Http\Controllers\Admin\Contact;

use App\Http\Controllers\Controller;

class ContactControllerAr extends Controller
{
    
}
