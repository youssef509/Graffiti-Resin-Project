<html>
<body>
<h2>طلب تدريب واشراف جديد!'</h2>
<p><strong>Name:</strong> {{ $data['name'] }}</p>
<p><strong>Age:</strong> {{ $data['age'] }}</p>
<p><strong>Phone:</strong> {{ $data['phone'] }}</p>
<p><strong>City:</strong> {{ $data['city'] }}</p>
<p><strong>Specialization:</strong> {{ $data['specialization'] }}</p>
<p><strong>Current Job:</strong> {{ $data['current_job'] }}</p>
<p><strong>Reason:</strong> {{ $data['reason'] }}</p>
</body>
</html>
